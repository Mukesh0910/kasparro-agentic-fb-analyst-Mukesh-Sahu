"""
Kasparro - Agentic Facebook Ads Analyst
"""

__version__ = "1.0.0"
