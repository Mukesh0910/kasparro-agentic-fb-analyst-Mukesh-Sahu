"""
Agent modules for Kasparro
"""
